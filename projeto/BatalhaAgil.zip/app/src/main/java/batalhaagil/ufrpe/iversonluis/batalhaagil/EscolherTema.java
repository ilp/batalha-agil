package batalhaagil.ufrpe.iversonluis.batalhaagil;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class EscolherTema extends AppCompatActivity {
    private Spinner spinTema;
    private Button btn_desafiar;
    TextView txt;

    int flags[] = {R.drawable.ic_random, R.drawable.ic_cancel, R.drawable.ic_scrum, R.drawable.ic_cancel};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolher_tema);

        spinTema = (Spinner) findViewById(R.id.spinner_tema);
        btn_desafiar = (Button) findViewById(R.id.btn_desafiar);
        txt = (TextView) findViewById(R.id.titulo_escolher_tema);
        Typeface typeface=Typeface.createFromAsset(getAssets(), "fonts/Bungasai.ttf");
        txt.setTypeface(typeface);

        CustomSpinnerTema customAdapter = new CustomSpinnerTema(getApplicationContext(),flags,getResources().getStringArray(R.array.temas_array));
        spinTema.setAdapter(customAdapter);

        btn_desafiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(EscolherTema.this, CreateMapa.class);
                startActivity(it);
                finish();
            }
        });

    }

}
