package batalhaagil.ufrpe.iversonluis.batalhaagil;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TelaInicial extends AppCompatActivity {

    private TextView btnIniciar;
    private ImageView navio1;
    private ImageView navio2;
    private ImageView navio3;
    private ImageView navio4;
    private ImageView navio5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        btnIniciar = (TextView) findViewById(R.id.btnIniciar);
        navio1 = (ImageView) findViewById(R.id.navio1);
        navio2 = (ImageView) findViewById(R.id.navio2);
        navio3 = (ImageView) findViewById(R.id.navio3);
        navio4 = (ImageView) findViewById(R.id.navio4);
        navio5 = (ImageView) findViewById(R.id.navio5);

        Typeface typeface=Typeface.createFromAsset(getAssets(), "fonts/Bungasai.ttf");
        btnIniciar.setTypeface(typeface);

        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation a = AnimationUtils.loadAnimation(TelaInicial.this, R.anim.milkshake);
                btnIniciar.startAnimation(a);
                btnIniciar.setTextColor(ContextCompat.getColor(TelaInicial.this, R.color.colorPrimaryDark));

                TranslateAnimation animation = new TranslateAnimation(0,-1500,0,0);
                animation.setDuration(2000);
                animation.setFillAfter(false);

                TranslateAnimation animation2 = new TranslateAnimation(0,1500,0,0);
                animation2.setDuration(2000);
                animation2.setFillAfter(false);

                navio1.startAnimation(animation);
                navio2.startAnimation(animation2);
                navio3.startAnimation(animation);
                navio4.startAnimation(animation2);
                navio5.startAnimation(animation2);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent it = new Intent(TelaInicial.this, EscolherTema.class);
                        startActivity(it);
                        finish();
                    }
                }, 900);

            }
        });
    }

}
