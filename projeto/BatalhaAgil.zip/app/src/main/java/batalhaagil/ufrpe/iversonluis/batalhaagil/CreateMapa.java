package batalhaagil.ufrpe.iversonluis.batalhaagil;

import android.content.ClipData;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class CreateMapa extends AppCompatActivity {

    GridLayout gridMap;
    //GridView gridMap;
    GridView gridShips;
    GridView gridViewLinhas;
    GridView gridViewColunas;
    ArrayList<Integer> listShips;
    Button btnNext;
    ImageView[] barcos;

    String [] linhas = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    String [] colunas = new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_mapa);

        //gridMap = (GridView) findViewById(R.id.gridMap);
        gridMap = (GridLayout) findViewById(R.id.gridMap);
        gridMap.setOnDragListener(new DragListener());
        gridShips = (GridView) findViewById(R.id.gridShips);

        carregarShips();
        gridShips.setAdapter((new ImageAdapter(this, listShips)));

        carregarMapa();
        //gridMap.setAdapter(new ImageAdapter(this, listShips));

        //numeros das colunas e linhas
        gridViewLinhas = (GridView) findViewById(R.id.gridviewLinhas);
        gridViewColunas = (GridView) findViewById(R.id.gridviewColunas);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, linhas);
        gridViewLinhas.setAdapter(adapter);
        adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, colunas);
        gridViewColunas.setAdapter(adapter);

        btnNext = (Button)findViewById(R.id.btn_next);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(CreateMapa.this, TelaBatalha.class);
                startActivity(it);
                finish();
            }
        });



        //asdasdadadasdasdas

        barcos = new ImageView[100];

        for(int i =0; i < 100; i++){
            barcos[i] = new ImageView(CreateMapa.this);
            barcos[i].setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
            barcos[i].setOnLongClickListener(new LongPressListener());

            if(i == 11){
                barcos[i].setImageResource(R.drawable.ic_barc_tam4_1);
                gridMap.addView(barcos[i]);
            } else if( i == 12){
                barcos[i].setImageResource(R.drawable.ic_barc_tam4_2);
                gridMap.addView(barcos[i]);
            } else if( i == 13){
                barcos[i].setImageResource(R.drawable.ic_barc_tam4_3);
                gridMap.addView(barcos[i]);
            } else if( i == 14){
                barcos[i].setImageResource(R.drawable.ic_barc_tam4_4);
                gridMap.addView(barcos[i]);
            } else if(i == 31 || i == 35){
                barcos[i].setImageResource(R.drawable.ic_barc_tam3_1);
                gridMap.addView(barcos[i]);
            } else if(i == 32 || i == 36) {
                barcos[i].setImageResource(R.drawable.ic_barc_tam3_2);
                gridMap.addView(barcos[i]);
            } else if(i == 33 || i == 37) {
                barcos[i].setImageResource(R.drawable.ic_barc_tam3_3);
                gridMap.addView(barcos[i]);
            } else if(i == 51 || i == 54 || i == 57) {
                barcos[i].setImageResource(R.drawable.ic_barc_tam2_1);
                gridMap.addView(barcos[i]);
            } else if(i == 52 || i == 55 || i == 58){
                barcos[i].setImageResource(R.drawable.ic_barc_tam2_2);
                gridMap.addView(barcos[i]);
            } else if (i == 71 || i==73 || i== 75 || i==77){
                barcos[i].setImageResource(R.drawable.ic_barco_tam1);
                gridMap.addView(barcos[i]);
            } else{
                barcos[i].setImageResource(R.drawable.ic_barco2_preto);
                gridMap.addView(barcos[i]);
            }

        }

        int item = 0;

        for(item=0;item<100;item++)
        {
            final int finalItem = item;
            barcos[item].setOnClickListener(new View.OnClickListener() {

                int pos = finalItem;

                public void onClick(View v) {
                    Log.i("Click", "posicao: " + pos);
                    Toast.makeText(getBaseContext(), pos+" Clicked",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    public void carregarShips(){
        listShips = new ArrayList<>();
        for(int i = 0;i < 100; i++){
            if(i == 11){
                listShips.add(R.drawable.ic_barc_tam4_1);
            } else if( i == 12){
                listShips.add(R.drawable.ic_barc_tam4_2);
            } else if( i == 13){
                listShips.add(R.drawable.ic_barc_tam4_3);
            } else if( i == 14){
                listShips.add(R.drawable.ic_barc_tam4_4);
            } else if(i == 31 || i == 35){
                listShips.add(R.drawable.ic_barc_tam3_1);
            } else if(i == 32 || i == 36) {
                listShips.add(R.drawable.ic_barc_tam3_2);
            } else if(i == 33 || i == 37) {
                listShips.add(R.drawable.ic_barc_tam3_3);
            } else if(i == 51 || i == 54 || i == 57) {
                listShips.add(R.drawable.ic_barc_tam2_1);
            } else if(i == 52 || i == 55 || i == 58){
                listShips.add(R.drawable.ic_barc_tam2_2);
            } else if (i == 71 || i==73 || i== 75 || i==77){
                listShips.add(R.drawable.ic_barco_tam1);
            } else{
                listShips.add(R.drawable.ic_barco2_preto);
            }
        }
    }

    public void carregarMapa(){
        listShips = new ArrayList<>();
        for(int i = 0; i < 100; i++){
            listShips.add(R.drawable.ic_barco2_preto);
        }

    }

    class LongPressListener implements View.OnLongClickListener {
        @Override
        public boolean onLongClick(View view) {
            final ClipData data = ClipData.newPlainText("", "");
            View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
            view.startDrag(data, shadowBuilder, view, 0);
            view.setVisibility(View.INVISIBLE);
            return true;
        }
    }

    class DragListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            final View view = (View) event.getLocalState();
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_LOCATION:
                    // do nothing if hovering above own position
                    if (view == v) return true;
                    // get the new list index
                    final int index = calculateNewIndex(event.getX(), event.getY());
                    // remove the view from the old position
                    gridMap.removeView(view);
                    // and push to the new
                    gridMap.addView(view, index);
                    break;
                case DragEvent.ACTION_DROP:
                    view.setVisibility(View.VISIBLE);
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    if (!event.getResult()) {
                        view.setVisibility(View.VISIBLE);
                    }
                    break;
            }
            return true;
        }

        private int calculateNewIndex(float x, float y) {
            // calculate which column to move to
            final float cellWidth = gridMap.getWidth() / gridMap.getColumnCount();
            final int column = (int)(x / cellWidth);

            // calculate which row to move to
            final float cellHeight = gridMap.getHeight() / gridMap.getRowCount();
            final int row = (int)Math.floor(y / cellHeight);

            // the items in the GridLayout is organized as a wrapping list
            // and not as an actual grid, so this is how to get the new index
            int index = row * gridMap.getColumnCount() + column;
            if (index >= gridMap.getChildCount()) {
                index = gridMap.getChildCount() - 1;
            }

            return index;
        }
    }
}
