package batalhaagil.ufrpe.iversonluis.batalhaagil;

import android.app.Dialog;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaBatalha extends AppCompatActivity {

    GridView gridview;
    GridView gridview2;
    GridView gridViewLinhas;
    GridView gridViewColunas;
    ArrayList<Integer> listfundo;

    ImageView btnCancelar;

    String [] linhas = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    String [] colunas = new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_batalha);

        gridview = (GridView) findViewById(R.id.gridview);
        gridview2 = (GridView) findViewById(R.id.gridview2);

        //Colunas e linhas
        gridViewLinhas = (GridView) findViewById(R.id.gridviewLinhas);
        gridViewColunas = (GridView) findViewById(R.id.gridviewColunas);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, linhas);
        gridViewLinhas.setAdapter(adapter);
        adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, colunas);
        gridViewColunas.setAdapter(adapter);

        gridViewLinhas = (GridView) findViewById(R.id.gridviewLinhas2);
        gridViewColunas = (GridView) findViewById(R.id.gridviewColunas2);

        adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, linhas);
        gridViewLinhas.setAdapter(adapter);
        adapter = new ArrayAdapter<String>(this, R.layout.linhas_colunas, colunas);
        gridViewColunas.setAdapter(adapter);
        //End colunas e linhas

        carregarTela();

        gridview.setAdapter(new ImageAdapter(this,listfundo));
        gridview2.setAdapter(new ImageAdapter(this, listfundo));

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(TelaBatalha.this, "" + position,
                        Toast.LENGTH_SHORT).show();
                v.setOnLongClickListener(new MyOnLongClickListener());
                gridview.setOnDragListener(new MyOnDragListener(position));
            }
        });

        gridview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(TelaBatalha.this, "" + position,
                        Toast.LENGTH_SHORT).show();
                v.setOnLongClickListener(new MyOnLongClickListener());
                gridview2.setOnDragListener(new MyOnDragListener(position));
            }
        });


        btnCancelar = (ImageView) findViewById(R.id.btn_cancelar);
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* AlertDialog.Builder builder = new AlertDialog.Builder(TelaBatalha.this);
                LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View view = inflater.inflate(R.layout.dialog_cancel_game, null);
                builder.setView(view);
                ImageView img = (ImageView) findViewById(R.id.title_dialog_cancel);
                builder.setCustomTitle(img);
                AlertDialog alert = builder.create();
                alert.show();*/

                final Dialog dialog = new Dialog(TelaBatalha.this);
                dialog.setContentView(R.layout.dialog_cancel_game);
                dialog.setTitle(R.string.cancel_title);
                dialog.show();

                Button btnCancelar2 = (Button) dialog.findViewById(R.id.btn_cancelar_game);
                btnCancelar2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                Button btnFechar = (Button) dialog.findViewById(R.id.btn_quit);
                btnFechar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent it = new Intent(TelaBatalha.this, TelaInicial.class);
                        startActivity(it);
                        finish();
                    }
                });
            }
        });
    }

    public void carregarTela(){
        listfundo = new ArrayList<>();
        for(int i = 0;i < 100; i++){
            if(i == 42){
                listfundo.add(R.drawable.ic_barc_tam4_1);
            } else if( i == 43){
                listfundo.add(R.drawable.ic_barc_tam4_2);
            } else if( i == 44){
                listfundo.add(R.drawable.ic_barc_tam4_3);
            } else if( i == 45){
                listfundo.add(R.drawable.ic_barc_tam4_4);
            } else{
                listfundo.add(R.drawable.ic_barco2_preto);
            }
        }
    }

    class MyOnLongClickListener implements View.OnLongClickListener {
        @Override
        public boolean onLongClick(View v) {
            ClipData data = ClipData.newPlainText("simple_text", "text");
            View.DragShadowBuilder sb = new View.DragShadowBuilder(findViewById(R.id.img_barco));
            v.startDrag(data, sb, v, 0);
            v.setVisibility(View.INVISIBLE);
            return(true);
        }
    }

    class MyOnDragListener implements View.OnDragListener {
        private int num;

        public MyOnDragListener(int num) {
            super();
            this.num = num;
        }

        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();

            switch (action) {
                case DragEvent.ACTION_DRAG_STARTED:
                    Log.i("Script", num + " - ACTION_DRAG_STARTED");
                    if (event.getClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                        return (true);
                    }
                    return (false);
                case DragEvent.ACTION_DRAG_ENTERED:
                    Log.i("Script", num + " - ACTION_DRAG_ENTERED");
                    v.setBackgroundColor(Color.YELLOW);
                    break;
                case DragEvent.ACTION_DRAG_LOCATION:
                    Log.i("Script", num + " - ACTION_DRAG_LOCATION");
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    Log.i("Script", num + " - ACTION_DRAG_EXITED");
                    v.setBackgroundColor(Color.BLUE);
                    break;
                case DragEvent.ACTION_DROP:
                    Log.i("Script", num + " - ACTION_DROP");
                    View view = (View) event.getLocalState();
                    ViewGroup owner = (ViewGroup) view.getParent();
                    owner.removeViewInLayout(view);
                    GridView container =  (GridView) v;
                    //v = inflate(R.layout.barco, container, false);
                    container.addView(view);
                    view.setVisibility(View.VISIBLE);
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    Log.i("Script", num + " - ACTION_DRAG_ENDED");
                    v.setBackgroundResource(R.drawable.background_grid);
                    break;
            }

            return true;
        }
    }
}
